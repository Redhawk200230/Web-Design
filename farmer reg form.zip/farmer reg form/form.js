const validCrops = ['rice', 'wheat', 'corn', 'soybean', 'barley', 'oat', 'potato', 'tomato'];

function levenshtein(a, b) {
    const matrix = [];
    let i;
    for (i = 0; i <= b.length; i++) matrix[i] = [i];
    let j;
    for (j = 0; j <= a.length; j++) matrix[0][j] = j;
    for (i = 1; i <= b.length; i++) {
        for (j = 1; j <= a.length; j++) {
            if (b.charAt(i - 1) === a.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            } else {
                matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, Math.min(matrix[i][j - 1] + 1, matrix[i - 1][j] + 1));
            }
        }
    }
    return matrix[b.length][a.length];
}

function findClosestCrop(input) {
    let closestCrop = validCrops[0];
    let minDistance = levenshtein(input, validCrops[0]);
    for (let i = 1; i < validCrops.length; i++) {
        const distance = levenshtein(input, validCrops[i]);
        if (distance < minDistance) {
            minDistance = distance;
            closestCrop = validCrops[i];
        }
    }
    return closestCrop;
}

function correctCropName(inputElement) {
    const input = inputElement.value.toLowerCase();
    const closestCrop = findClosestCrop(input);
    if (input !== closestCrop) {
        alert(`Did you mean "${closestCrop}"?`);
        inputElement.value = closestCrop;
    }
}

function addCropEntry() {
    const cropsDiv = document.getElementById('crops');
    const newEntry = document.createElement('div');
    newEntry.className = 'crop-entry';
    newEntry.innerHTML = `
    <div id="crops">
    <div class="crop-entry">

        <div class="form-group">
            <div class="row">
                <div class="column">

                    <label for="cropType">Crop Type:</label>
                    <input list="cropList" name="cropType[]" required onblur="correctCropName(this)">
                    <datalist id="cropList">
                        <option value="rice">
                        <option value="wheat">
                        <option value="corn">
                        <option value="soybean">
                        <option value="barley">
                        <option value="oat">
                        <option value="potato">
                        <option value="tomato">
                    </datalist>

                </div>


                <div class="column">
                    <label for="landUsed">Land Used (acres):</label>
                    <input type="number" name="landUsed[]" required>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="season">Seasonality:</label>
            <select name="season[]" id="season">
                <option value="spring">Spring</option>
                <option value="summer">Summer</option>
                <option value="fall">Fall</option>
                <option value="winter">Winter</option>
            </select>
        </div>
        <div class="form-group">
            <div class="row">
                <div class="column">
                    <label for="yeild">Harvested Yield:</label>
                    <input type="number" id="yeild" name="yeild" required>
                </div>
                <div class="column">
                    <label for="yeild">Expected Yield:</label>
                    <input type="number" id="yeild" name="yeild" required>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="rotation">Crop Rotation:</label>
            <input type="checkbox" name="rotation[]" id="rotation">
        </div>
        <div class="form-group">
            <label for="irrigation">Irrigation System:</label>
            <select name="irrigation[]" id="irrigation">
                <option value="drip">Drip</option>
                <option value="sprinkler">Sprinkler</option>
                <option value="flood">Flood</option>
                <option value="pivot">Pivot</option>
            </select>
        </div>
        <div class="form-group">
            <label for="notes">Notes:</label>
            <textarea name="notes[]" id="notes" rows="3"></textarea>
        </div>
    </div>
</div>
    `;
    cropsDiv.appendChild(newEntry);
}
