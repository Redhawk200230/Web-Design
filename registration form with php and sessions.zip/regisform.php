<!DOCTYPE html>
<html lang="en">
<head>
    <title>registration</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="style_r.css">
</head>
<body>
    <header>
    <div class="fluid-container">
            <div class="row mar">
                <div class="col-md-12">
                    <div class="d" >
                        <?php
                        echo date("d/m/Y");
                        echo ",";
                        echo date("l");
                        ?>
                    </div>
                </div>
            </div>
        </div>
</header>
   <section>
    <div class="container"> 
    <form action="regform.php" method="get">
    <h1>Enter Your Information</h1>
        Employee Name: <input type="text" name="name"><br>
        Age: <input type="number" name="age" ><br>
        <label>  
            Gender:   
            </label>  
            <input type="radio" id="gender" name="gender" value="male"/> Male    
         
            <input type="radio" id="gender" name="gender" value="female"/> Female <br/> 
        Education:<input list="Dropdown" placeholder = "Choose your Stream" name="ed">
                    <datalist id="Dropdown">
                     <option value="BCA">
                     <option value="MCA">
                     <option value="M.Sc">
                     <option value="M.Tech">
                    <option value="BBA">
             </datalist><br>
        <input type="submit" >
     </form>
        <?php
        if(isset($_GET['submit'])){
            $check=$_GET['submit'];
            if($check=="wrong"){
                echo "<p class='error'>Name can not be blank </p>";
            }
            elseif($check=="wr"){
                echo "<p class='error'>Name can only conatain alphabets </p>";
            }
        }
        if(isset($_GET['submit'])){
            $check=$_GET['submit'];
            if($check=="w"){
                echo "<p class='error'>Similar data registered previously </p>";
            }
        }
        if(isset($_GET['submit'])){
            $check=$_GET['submit'];
            if($check=="f"){
                echo "<p class='error'>Data Deleted </p>";
            }
           
        }
        ?>
        </div>
        </section>
            <footer class="da">
            <?php include 'footer.php';?>
    </footer>
</body> 
</html>