<html>
    <head>
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
         <link rel='stylesheet' href="style_de.css">
    </head>
    <body>
<?php 
// $nameErr = "";
// $name =  $_GET["name"];  
$age = $_GET["age"];
$gender = $_GET["gender"];
$ed = $_GET["ed"];

// header ("Location: regisform.php");
// echo $name;
// echo $age;
// echo $gender;
// echo GET


?>
<!-- <table border="2" >
    <tr>
        <th>Name</th>   
        <th>Age</th>
        <th>Gender</th>
        <th>Education</th> -->
    </tr>
    
        <?php
        $name=" ";
        $name=$_GET["name"];
            if (empty($_GET["name"])) 
            // if($name== NULL)
            {
                header("Location: http://localhost/training/regisform.php?submit=wrong");
                exit();
            } else {
              $name = ($_GET["name"]);
              // check if name only contains letters and whitespace
              if (!preg_match("/^[a-zA-Z-' ]*$/",$name)){
                 header("Location: http://localhost/training/regisform.php?submit=wr");
                 exit();
              }
            } 
            $ar=array(  "name" => $name,
                        "age" => $age,
                        "gender" => $gender, 
                        "ed" => $ed);         
        ?>
      
 <?php
 // $resultSet=[];
 // $val1=serialize($ar);
 // setcookie('values',$val1);
 // $dat=$_COOKIE['values'];
 // $data=unserialize($dat);
 
 // array_push($resultSet,$data);
 $cookiename = "emp";
 $c = array();
 // $pid = $_POST['id'];
 if (!empty($_COOKIE[$cookiename])) {
     $c = unserialize($_COOKIE[$cookiename]);
     
   if(in_array($ar,$c)){
    header("Location: http://localhost/training/regisform.php?submit=w");
   } else {
    array_push($c, $ar);

   }

  
    
   
 } 

 setcookie($cookiename, serialize($c), time() + 86500);
 $_COOKIE[$cookiename] = serialize($c); 

//  echo '<pre>';
//  print_r ($c);
//  echo '</pre>';

 ?>
 </tr>
 <br>
<h1 align="center">EMPLOYEE DETAILS</h1>
<table border=2px align="center" >
   
    <tr bgcolor="lightgreen">
        <th>Employee Name</th>
        <th>Age</th>
        <th>Gender</th>
        <th>Education</th> 
        <th>Action</th>      
    </tr>
    <?php
// $value=$_COOKIE["ar"];//returns cookie value  

foreach($c as $key => $vl){
    
    echo "<tr>";
    // echo $key.' : '.$vl.'<br>';
    foreach($vl as $v){
    if ($v== '') {
        echo "<td>".("N/A")."</td>";
        
    } else {
        echo "<td>".$v."</td>";
    }
} 


   
echo "<td><a href='delete.php?rn=$key'>Delete</a></td>";
echo "</tr>"; 
}

// header("Location: https://example.com/myOtherPage.php");\

    ?>
 </table>
</body>
</html>