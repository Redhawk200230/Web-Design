<?php
// include "regform.php";
if(isset($_GET["rn"])){  
$check=$_GET["rn"];
// if(20){
    if(!empty($_COOKIE["emp"])){
    $g=unserialize($_COOKIE["emp"]);
    unset($g[$check]);
   
}

setcookie("emp", serialize($g), time() + 86500);
$_COOKIE["emp"] = serialize($g); 
header("Location: http://localhost/training/regisform.php?submit=f");
}    
?>